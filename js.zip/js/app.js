import {
    $
} from "./storage.js";


let authInit = null;
let profileInit = null;
let visualsInit = null;

let dashboardInit = null;
let dashboardRender = null;

let subjectsInit = null;
let questionsInit = null;
let tasksInit = null;

let examsInit = null;
let examsRender = null;

let testsInit = null;
let plannerInit = null;

let timerInit = null;
let analyticsInit = null;

let resourcesInit = null;
let resourcesRender = null;

let rewardsInit = null;

let aiInit = null;

let snapshotInit = null;
let snapshotRender = null;


/* =====================================================
   LOAD MODULE
   ===================================================== */

async function loadModule(
    path,
    names
){

    try{

        const module =
            await import(path);


        for(
            const name of names
        ){

            if(
                typeof module[name] ===
                "function"
            ){

                return module[name];

            }

        }

    }
    catch(error){

        console.error(
            "Synaptiq module:",
            path,
            error
        );

    }


    return null;

}


/* =====================================================
   LOAD ALL
   ===================================================== */

async function loadModules(){

    authInit =
        await loadModule(
            "./auth.js",
            ["initAuth"]
        );


    profileInit =
        await loadModule(
            "./profile.js",
            ["initProfile"]
        );


    visualsInit =
        await loadModule(
            "./visuals.js",
            ["initVisuals"]
        );


    dashboardInit =
        await loadModule(
            "./dashboard.js",
            ["initDashboard"]
        );


    dashboardRender =
        await loadModule(
            "./dashboard.js",
            [
                "renderDashboard",
                "updateDashboard"
            ]
        );


    subjectsInit =
        await loadModule(
            "./subjects.js",
            ["initSubjects"]
        );


    questionsInit =
        await loadModule(
            "./questions.js",
            ["initQuestions"]
        );


    tasksInit =
        await loadModule(
            "./tasks.js",
            ["initTasks"]
        );


    examsInit =
        await loadModule(
            "./exams.js",
            ["initExams"]
        );


    examsRender =
        await loadModule(
            "./exams.js",
            ["renderExams"]
        );


    testsInit =
        await loadModule(
            "./tests.js",
            ["initTests"]
        );


    plannerInit =
        await loadModule(
            "./planner.js",
            ["initPlanner"]
        );


    timerInit =
        await loadModule(
            "./timer.js",
            ["initTimer"]
        );


    analyticsInit =
        await loadModule(
            "./analytics.js",
            ["initAnalytics"]
        );


    resourcesInit =
        await loadModule(
            "./resources.js",
            ["initResources"]
        );


    resourcesRender =
        await loadModule(
            "./resources.js",
            ["renderResources"]
        );


    rewardsInit =
        await loadModule(
            "./rewards.js",
            ["initRewards"]
        );


    aiInit =
        await loadModule(
            "./ai.js",
            [
                "initAI",
                "initAi"
            ]
        );


    snapshotInit =
        await loadModule(
            "./snapshot.js",
            ["initSnapshot"]
        );


    snapshotRender =
        await loadModule(
            "./snapshot.js",
            ["renderSnapshot"]
        );

}


/* =====================================================
   HOME
   ===================================================== */

function setupHome(){

    $("startBtn")
        ?.addEventListener(
            "click",
            () => {

                $("home")
                    ?.classList.add(
                        "hidden"
                    );

                $("auth")
                    ?.classList.remove(
                        "hidden"
                    );

            }
        );


    $("loginBtn")
        ?.addEventListener(
            "click",
            () => {

                $("home")
                    ?.classList.add(
                        "hidden"
                    );

                $("auth")
                    ?.classList.remove(
                        "hidden"
                    );

            }
        );


    $("backBtn")
        ?.addEventListener(
            "click",
            () => {

                $("auth")
                    ?.classList.add(
                        "hidden"
                    );

                $("home")
                    ?.classList.remove(
                        "hidden"
                    );

            }
        );


    $("exploreBtn")
        ?.addEventListener(
            "click",
            () => {

                $("features")
                    ?.scrollIntoView({
                        behavior:"smooth"
                    });

            }
        );

}


/* =====================================================
   NAVIGATION
   ===================================================== */

function setupNavigation(){

    document
        .querySelectorAll(
            "[data-page]"
        )
        .forEach(
            button => {

                button.addEventListener(
                    "click",
                    () => {

                        const page =
                            button.dataset.page;


                        showPage(
                            page
                        );


                        document
                            .querySelectorAll(
                                ".menu"
                            )
                            .forEach(
                                item =>
                                    item.classList
                                        .remove(
                                            "active"
                                        )
                            );


                        button.classList.add(
                            "active"
                        );


                        refreshPage(
                            page
                        );

                    }
                );

            }
        );

}


export function showPage(
    pageId
){

    document
        .querySelectorAll(
            "#dashboard .page"
        )
        .forEach(
            page =>
                page.classList.add(
                    "hidden"
                )
        );


    $(pageId)
        ?.classList.remove(
            "hidden"
        );

}


/* =====================================================
   REFRESH PAGE
   ===================================================== */

function refreshPage(
    pageId
){

    if(
        pageId ===
        "dashboardPage"
    ){

        dashboardRender?.();

    }


    if(
        pageId ===
        "examsPage"
    ){

        examsRender?.();

    }


    if(
        pageId ===
        "resourcesPage"
    ){

        resourcesRender?.();

    }


    if(
        pageId ===
        "snapshotPage"
    ){

        snapshotRender?.();

    }

}


/* =====================================================
   MODALS
   ===================================================== */

function setupModals(){

    document
        .querySelectorAll(
            "[data-close]"
        )
        .forEach(
            button => {

                button.addEventListener(
                    "click",
                    () => {

                        $(
                            button.dataset.close
                        )
                        ?.classList.add(
                            "hidden"
                        );

                    }
                );

            }
        );


    document.addEventListener(
        "click",
        event => {

            if(
                event.target.classList.contains(
                    "modal"
                )
            ){

                event.target.classList.add(
                    "hidden"
                );

            }

        }
    );

}


/* =====================================================
   THEME
   ===================================================== */

function setupTheme(){

    function toggleTheme(){

        document.body
            .classList
            .toggle(
                "dark"
            );


        localStorage.setItem(
            "synaptiqTheme",
            document.body.classList.contains(
                "dark"
            )
                ? "dark"
                : "light"
        );

    }


    $("homeTheme")
        ?.addEventListener(
            "click",
            toggleTheme
        );


    $("dashTheme")
        ?.addEventListener(
            "click",
            toggleTheme
        );


    if(
        localStorage.getItem(
            "synaptiqTheme"
        ) ===
        "dark"
    ){

        document.body
            .classList.add(
                "dark"
            );

    }

}


/* =====================================================
   QUICK ACTIONS
   ===================================================== */

function setupQuickActions(){

    const actions = {

        qaSubject:
            "subjectModal",

        qaQuestion:
            "questionModal",

        qaTask:
            "taskModal",

        qaExam:
            "examModal",

        qaPlanner:
            "plannerModal",

        goalBtn:
            "goalModal"

    };


    Object.entries(
        actions
    )
    .forEach(
        (
            [buttonId,modalId]
        ) => {

            $(buttonId)
                ?.addEventListener(
                    "click",
                    () => {

                        $(modalId)
                            ?.classList
                            .remove(
                                "hidden"
                            );

                    }
                );

        }
    );

}


/* =====================================================
   NOTIFICATIONS
   ===================================================== */

function setupNotifications(){

    $("notificationBtn")
        ?.addEventListener(
            "click",
            () => {

                $("notificationBox")
                    ?.classList
                    .toggle(
                        "hidden"
                    );

            }
        );

}


/* =====================================================
   PROFILE EVENTS
   ===================================================== */

function setupProfileEvents(){

    window.addEventListener(
        "synaptiqProfileUpdated",
        () => {

            dashboardRender?.();

            examsRender?.();

            resourcesRender?.();

            snapshotRender?.();

        }
    );


    window.addEventListener(
        "synaptiqLogin",
        () => {

            setTimeout(
                () => {

                    dashboardRender?.();

                    examsRender?.();

                    resourcesRender?.();

                    snapshotRender?.();

                },
                100
            );

        }
    );

}


/* =====================================================
   INITIALIZE
   ===================================================== */

async function initialize(){

    await loadModules();


    try{
        authInit?.();
    }
    catch(error){
        console.error("Auth:",error);
    }


    try{
        profileInit?.();
    }
    catch(error){
        console.error("Profile:",error);
    }


    try{
        visualsInit?.();
    }
    catch(error){
        console.error("Visuals:",error);
    }


    try{
        dashboardInit?.();
    }
    catch(error){
        console.error("Dashboard:",error);
    }


    try{
        subjectsInit?.();
    }
    catch(error){
        console.error("Subjects:",error);
    }


    try{
        questionsInit?.();
    }
    catch(error){
        console.error("Questions:",error);
    }


    try{
        tasksInit?.();
    }
    catch(error){
        console.error("Tasks:",error);
    }


    try{

        examsInit?.(
            () =>
                dashboardRender?.()
        );

    }
    catch(error){

        console.error("Exams:",error);

    }


    try{
        testsInit?.();
    }
    catch(error){
        console.error("Tests:",error);
    }


    try{
        plannerInit?.();
    }
    catch(error){
        console.error("Planner:",error);
    }


    try{
        timerInit?.();
    }
    catch(error){
        console.error("Timer:",error);
    }


    try{
        analyticsInit?.();
    }
    catch(error){
        console.error("Analytics:",error);
    }


    try{
        resourcesInit?.();
    }
    catch(error){
        console.error("Resources:",error);
    }


    try{
        rewardsInit?.();
    }
    catch(error){
        console.error("Rewards:",error);
    }


    try{
        aiInit?.();
    }
    catch(error){
        console.error("AI:",error);
    }


    try{
        snapshotInit?.();
    }
    catch(error){
        console.error("Snapshot:",error);
    }


    dashboardRender?.();

}


/* =====================================================
   START
   ===================================================== */

function start(){

    setupHome();

    setupNavigation();

    setupModals();

    setupTheme();

    setupQuickActions();

    setupNotifications();

    setupProfileEvents();

    initialize();

}


start();
import {
    get,
    set,
    uid,
    $,
    esc,
    dateText
} from "./storage.js";

import {
    getProfile
} from "./profile.js";


/* =========================================================
   EXAM DIRECTORY
   ========================================================= */

const EXAM_DIRECTORY = [

    /* ENGINEERING */

    {
        name:"GATE",
        category:"Engineering",
        organization:"IIT Madras",
        official:"https://gate2027.iitm.ac.in/",
        pyq:"https://gate2027.iitm.ac.in/download",
        pyqLabel:"GATE Papers",
        info:"Graduate Aptitude Test in Engineering",
        tags:[
            "gate",
            "engineering",
            "btech",
            "computer science",
            "cse",
            "ece",
            "mechanical",
            "electrical",
            "civil"
        ]
    },

    {
        name:"JEE Main",
        category:"Engineering",
        organization:"NTA",
        official:"https://jeemain.nta.nic.in/",
        pyq:"https://jeemain.nta.nic.in/",
        pyqLabel:"Question Papers",
        info:"Joint Entrance Examination Main",
        tags:[
            "jee",
            "engineering",
            "nta"
        ]
    },

    {
        name:"JEE Advanced",
        category:"Engineering",
        organization:"JEE Advanced",
        official:"https://jeeadv.ac.in/",
        pyq:"https://jeeadv.ac.in/archive.html",
        pyqLabel:"Question Papers",
        info:"Engineering entrance examination for IITs",
        tags:[
            "jee",
            "iit",
            "engineering"
        ]
    },


    /* MEDICAL */

    {
        name:"NEET UG",
        category:"Medical",
        organization:"NTA",
        official:"https://neet.nta.nic.in/",
        pyq:"https://neet.nta.nic.in/",
        pyqLabel:"Official Papers",
        info:"National Eligibility cum Entrance Test",
        tags:[
            "neet",
            "medical",
            "nta",
            "biology",
            "physics",
            "chemistry"
        ]
    },

    {
        name:"NEET PG",
        category:"Medical",
        organization:"NBEMS",
        official:"https://natboard.edu.in/",
        pyq:null,
        pyqLabel:"",
        info:"Postgraduate medical entrance examination",
        tags:[
            "neet",
            "medical",
            "pg"
        ]
    },

    {
        name:"INI-CET",
        category:"Medical",
        organization:"AIIMS",
        official:"https://www.aiimsexams.ac.in/",
        pyq:null,
        pyqLabel:"",
        info:"Institute of National Importance Combined Entrance Test",
        tags:[
            "medical",
            "aiims",
            "pg"
        ]
    },


    /* UNIVERSITY */

    {
        name:"CUET UG",
        category:"University",
        organization:"NTA",
        official:"https://cuet.nta.nic.in/",
        pyq:"https://cuet.nta.nic.in/documents/",
        pyqLabel:"Question Papers / Documents",
        info:"Common University Entrance Test UG",
        tags:[
            "cuet",
            "university",
            "nta"
        ]
    },

    {
        name:"CUET PG",
        category:"University",
        organization:"NTA",
        official:"https://exams.nta.ac.in/CUET-PG/",
        pyq:null,
        pyqLabel:"",
        info:"Common University Entrance Test PG",
        tags:[
            "cuet",
            "university",
            "pg"
        ]
    },


    /* UPSC */

    {
        name:"UPSC Civil Services",
        category:"UPSC",
        organization:"UPSC",
        official:"https://upsc.gov.in/",
        pyq:"https://www.upsc.gov.in/examinations/previous-question-papers",
        pyqLabel:"Previous Papers",
        info:"IAS, IPS, IFS and allied services",
        tags:[
            "upsc",
            "ias",
            "ips",
            "civil services"
        ]
    },

    {
        name:"UPSC IFoS",
        category:"UPSC",
        organization:"UPSC",
        official:"https://upsc.gov.in/",
        pyq:"https://www.upsc.gov.in/examinations/previous-question-papers",
        pyqLabel:"Previous Papers",
        info:"Indian Forest Service",
        tags:[
            "upsc",
            "forest",
            "ifos"
        ]
    },

    {
        name:"UPSC NDA",
        category:"Defence",
        organization:"UPSC",
        official:"https://upsc.gov.in/",
        pyq:"https://www.upsc.gov.in/examinations/previous-question-papers",
        pyqLabel:"Previous Papers",
        info:"National Defence Academy and Naval Academy",
        tags:[
            "nda",
            "defence",
            "upsc"
        ]
    },

    {
        name:"UPSC CDS",
        category:"Defence",
        organization:"UPSC",
        official:"https://upsc.gov.in/",
        pyq:"https://www.upsc.gov.in/examinations/previous-question-papers",
        pyqLabel:"Previous Papers",
        info:"Combined Defence Services",
        tags:[
            "cds",
            "defence",
            "upsc"
        ]
    },

    {
        name:"UPSC Engineering Services",
        category:"Engineering",
        organization:"UPSC",
        official:"https://upsc.gov.in/",
        pyq:"https://www.upsc.gov.in/examinations/previous-question-papers",
        pyqLabel:"Previous Papers",
        info:"Engineering Services Examination",
        tags:[
            "ese",
            "engineering",
            "upsc"
        ]
    },

    {
        name:"UPSC CMS",
        category:"Medical",
        organization:"UPSC",
        official:"https://upsc.gov.in/",
        pyq:"https://www.upsc.gov.in/examinations/previous-question-papers",
        pyqLabel:"Previous Papers",
        info:"Combined Medical Services",
        tags:[
            "cms",
            "medical",
            "upsc"
        ]
    },

    {
        name:"UPSC Geo-Scientist",
        category:"UPSC",
        organization:"UPSC",
        official:"https://upsc.gov.in/",
        pyq:"https://www.upsc.gov.in/examinations/previous-question-papers",
        pyqLabel:"Previous Papers",
        info:"Combined Geo-Scientist Examination",
        tags:[
            "geo scientist",
            "geology",
            "upsc"
        ]
    },


    /* SSC */

    {
        name:"SSC CGL",
        category:"SSC",
        organization:"SSC",
        official:"https://ssc.gov.in/",
        pyq:null,
        pyqLabel:"",
        info:"Combined Graduate Level Examination",
        tags:[
            "ssc",
            "government",
            "graduate"
        ]
    },

    {
        name:"SSC CHSL",
        category:"SSC",
        organization:"SSC",
        official:"https://ssc.gov.in/",
        pyq:null,
        pyqLabel:"",
        info:"Combined Higher Secondary Level Examination",
        tags:[
            "ssc",
            "12th"
        ]
    },

    {
        name:"SSC MTS",
        category:"SSC",
        organization:"SSC",
        official:"https://ssc.gov.in/",
        pyq:null,
        pyqLabel:"",
        info:"Multi-Tasking Staff Examination",
        tags:[
            "ssc",
            "government"
        ]
    },

    {
        name:"SSC GD",
        category:"SSC",
        organization:"SSC",
        official:"https://ssc.gov.in/",
        pyq:null,
        pyqLabel:"",
        info:"Constable General Duty Examination",
        tags:[
            "ssc",
            "defence",
            "gd"
        ]
    },

    {
        name:"SSC CPO",
        category:"SSC",
        organization:"SSC",
        official:"https://ssc.gov.in/",
        pyq:null,
        pyqLabel:"",
        info:"Sub-Inspector in Delhi Police and CAPFs",
        tags:[
            "ssc",
            "police",
            "cpo"
        ]
    },

    {
        name:"SSC JE",
        category:"SSC",
        organization:"SSC",
        official:"https://ssc.gov.in/",
        pyq:null,
        pyqLabel:"",
        info:"Junior Engineer Examination",
        tags:[
            "ssc",
            "engineering",
            "je"
        ]
    },

    {
        name:"SSC Stenographer",
        category:"SSC",
        organization:"SSC",
        official:"https://ssc.gov.in/",
        pyq:null,
        pyqLabel:"",
        info:"Stenographer Grade C and D",
        tags:[
            "ssc",
            "stenographer"
        ]
    },


    /* BANKING */

    {
        name:"IBPS PO",
        category:"Banking",
        organization:"IBPS",
        official:"https://www.ibps.in/",
        pyq:null,
        pyqLabel:"",
        info:"Probationary Officer",
        tags:[
            "ibps",
            "banking",
            "po"
        ]
    },

    {
        name:"IBPS Clerk",
        category:"Banking",
        organization:"IBPS",
        official:"https://www.ibps.in/",
        pyq:null,
        pyqLabel:"",
        info:"Clerical Cadre",
        tags:[
            "ibps",
            "banking",
            "clerk"
        ]
    },

    {
        name:"IBPS SO",
        category:"Banking",
        organization:"IBPS",
        official:"https://www.ibps.in/",
        pyq:null,
        pyqLabel:"",
        info:"Specialist Officer",
        tags:[
            "ibps",
            "banking",
            "specialist"
        ]
    },

    {
        name:"IBPS RRB PO",
        category:"Banking",
        organization:"IBPS",
        official:"https://www.ibps.in/",
        pyq:null,
        pyqLabel:"",
        info:"Regional Rural Bank Officer",
        tags:[
            "ibps",
            "rrb",
            "banking"
        ]
    },

    {
        name:"IBPS RRB Clerk",
        category:"Banking",
        organization:"IBPS",
        official:"https://www.ibps.in/",
        pyq:null,
        pyqLabel:"",
        info:"Regional Rural Bank Office Assistant",
        tags:[
            "ibps",
            "rrb",
            "banking"
        ]
    },

    {
        name:"SBI PO",
        category:"Banking",
        organization:"SBI",
        official:"https://sbi.co.in/web/careers",
        pyq:null,
        pyqLabel:"",
        info:"State Bank of India Probationary Officer",
        tags:[
            "sbi",
            "banking",
            "po"
        ]
    },

    {
        name:"SBI Clerk",
        category:"Banking",
        organization:"SBI",
        official:"https://sbi.co.in/web/careers",
        pyq:null,
        pyqLabel:"",
        info:"State Bank of India Junior Associate",
        tags:[
            "sbi",
            "banking",
            "clerk"
        ]
    },

    {
        name:"RBI Grade B",
        category:"Banking",
        organization:"RBI",
        official:"https://opportunities.rbi.org.in/",
        pyq:null,
        pyqLabel:"",
        info:"Reserve Bank of India Grade B",
        tags:[
            "rbi",
            "banking"
        ]
    },


    /* RAILWAYS */

    {
        name:"RRB NTPC",
        category:"Railways",
        organization:"Indian Railways",
        official:"https://indianrailways.gov.in/",
        pyq:null,
        pyqLabel:"",
        info:"Non-Technical Popular Categories",
        tags:[
            "rrb",
            "railway",
            "ntpc"
        ]
    },

    {
        name:"RRB Group D",
        category:"Railways",
        organization:"Indian Railways",
        official:"https://indianrailways.gov.in/",
        pyq:null,
        pyqLabel:"",
        info:"Level 1 railway recruitment",
        tags:[
            "rrb",
            "railway",
            "group d"
        ]
    },

    {
        name:"RRB JE",
        category:"Railways",
        organization:"Indian Railways",
        official:"https://indianrailways.gov.in/",
        pyq:null,
        pyqLabel:"",
        info:"Railway Junior Engineer",
        tags:[
            "rrb",
            "railway",
            "engineering"
        ]
    },


    /* MANAGEMENT */

    {
        name:"CAT",
        category:"Management",
        organization:"IIM",
        official:"https://iimcat.ac.in/",
        pyq:null,
        pyqLabel:"",
        info:"Common Admission Test",
        tags:[
            "cat",
            "mba",
            "management"
        ]
    },

    {
        name:"XAT",
        category:"Management",
        organization:"XLRI",
        official:"https://xatonline.in/",
        pyq:null,
        pyqLabel:"",
        info:"Xavier Aptitude Test",
        tags:[
            "xat",
            "mba",
            "management"
        ]
    },

    {
        name:"CMAT",
        category:"Management",
        organization:"NTA",
        official:"https://cmat.nta.nic.in/",
        pyq:"https://cmat.nta.nic.in/",
        pyqLabel:"Official Documents",
        info:"Common Management Admission Test",
        tags:[
            "cmat",
            "mba",
            "management",
            "nta"
        ]
    },

    {
        name:"MAT",
        category:"Management",
        organization:"AIMA",
        official:"https://mat.aima.in/",
        pyq:null,
        pyqLabel:"",
        info:"Management Aptitude Test",
        tags:[
            "mat",
            "mba",
            "management"
        ]
    },

    {
        name:"ATMA",
        category:"Management",
        organization:"AIMS",
        official:"https://atmaaims.com/",
        pyq:null,
        pyqLabel:"",
        info:"AIMS Test for Management Admissions",
        tags:[
            "atma",
            "mba",
            "management"
        ]
    },


    /* LAW */

    {
        name:"CLAT UG",
        category:"Law",
        organization:"Consortium of NLUs",
        official:"https://consortiumofnlus.ac.in/",
        pyq:null,
        pyqLabel:"",
        info:"Common Law Admission Test",
        tags:[
            "clat",
            "law",
            "nlu"
        ]
    },

    {
        name:"CLAT PG",
        category:"Law",
        organization:"Consortium of NLUs",
        official:"https://consortiumofnlus.ac.in/",
        pyq:null,
        pyqLabel:"",
        info:"CLAT Postgraduate",
        tags:[
            "clat",
            "law",
            "pg"
        ]
    },


    /* DEFENCE */

    {
        name:"AFCAT",
        category:"Defence",
        organization:"Indian Air Force",
        official:"https://afcat.cdac.in/",
        pyq:null,
        pyqLabel:"",
        info:"Air Force Common Admission Test",
        tags:[
            "afcat",
            "airforce",
            "defence"
        ]
    },

    {
        name:"Agniveer Army",
        category:"Defence",
        organization:"Indian Army",
        official:"https://joinindianarmy.nic.in/",
        pyq:null,
        pyqLabel:"",
        info:"Indian Army Agniveer recruitment",
        tags:[
            "agniveer",
            "army",
            "defence"
        ]
    },

    {
        name:"Indian Navy Agniveer",
        category:"Defence",
        organization:"Indian Navy",
        official:"https://joinindiannavy.gov.in/",
        pyq:null,
        pyqLabel:"",
        info:"Indian Navy Agniveer recruitment",
        tags:[
            "agniveer",
            "navy",
            "defence"
        ]
    },


    /* TEACHING */

    {
        name:"CTET",
        category:"Teaching",
        organization:"CBSE",
        official:"https://ctet.nic.in/",
        pyq:"https://ctet.nic.in/archive/",
        pyqLabel:"Previous Papers",
        info:"Central Teacher Eligibility Test",
        tags:[
            "ctet",
            "teaching",
            "cbse"
        ]
    },

    {
        name:"UGC NET",
        category:"Teaching",
        organization:"NTA",
        official:"https://ugcnet.nta.nic.in/",
        pyq:"https://ugcnet.nta.nic.in/archive/",
        pyqLabel:"Official Archive",
        info:"University Grants Commission National Eligibility Test",
        tags:[
            "ugc",
            "net",
            "teaching",
            "research"
        ]
    },

    {
        name:"CSIR UGC NET",
        category:"Teaching",
        organization:"NTA",
        official:"https://csirnet.nta.ac.in/",
        pyq:null,
        pyqLabel:"",
        info:"Joint CSIR-UGC NET",
        tags:[
            "csir",
            "net",
            "science",
            "research"
        ]
    },


    /* DESIGN */

    {
        name:"NIFT",
        category:"Design",
        organization:"NIFT",
        official:"https://nift.ac.in/admissions",
        pyq:null,
        pyqLabel:"",
        info:"National Institute of Fashion Technology Entrance",
        tags:[
            "nift",
            "design",
            "fashion"
        ]
    },

    {
        name:"NID DAT",
        category:"Design",
        organization:"NID",
        official:"https://admissions.nid.edu/",
        pyq:null,
        pyqLabel:"",
        info:"National Institute of Design Admission Test",
        tags:[
            "nid",
            "dat",
            "design"
        ]
    },

    {
        name:"NATA",
        category:"Architecture",
        organization:"Council of Architecture",
        official:"https://www.nata.in/",
        pyq:null,
        pyqLabel:"",
        info:"National Aptitude Test in Architecture",
        tags:[
            "nata",
            "architecture"
        ]
    }

];


/* =========================================================
   STATE
   ========================================================= */

let selectedCategory = "All";
let searchText = "";


/* =========================================================
   HELPERS
   ========================================================= */

function getSubjects(){

    return get(
        "subjects",
        []
    );

}


function getTrackedExams(){

    return get(
        "exams",
        []
    );

}


function daysUntil(
    date
){

    if(!date)
        return null;


    const target =
        new Date(
            `${date}T23:59:59`
        );


    return Math.ceil(
        (
            target -
            new Date()
        ) /
        86400000
    );

}


/* =========================================================
   PROFILE-BASED SCORE
   ========================================================= */

function examScore(
    exam
){

    let score = 0;


    const profile =
        getProfile();


    const target =
        String(
            profile.targetExam ||
            ""
        )
        .toLowerCase();


    const profileText = `
        ${profile.type || ""}
        ${profile.degree || ""}
        ${profile.branch || ""}
        ${profile.stream || ""}
        ${profile.profession || ""}
        ${profile.learningGoal || ""}
    `.toLowerCase();


    const subjects =
        Array.isArray(
            profile.subjects
        )
            ? profile.subjects
            : [];


    const examText = (
        exam.name +
        " " +
        exam.category +
        " " +
        exam.tags.join(" ")
    ).toLowerCase();


    /* Target exam */

    if(target){

        if(
            examText.includes(target) ||
            target.includes(
                exam.name.toLowerCase()
            )
        ){

            score += 10;

        }

    }


    /* Academic profile */

    if(
        profile.type ===
        "School Student"
    ){

        if(
            [
                "Engineering",
                "Medical",
                "University"
            ].includes(
                exam.category
            )
        ){

            score += 3;

        }

    }


    if(
        profile.type ===
        "College / University Student"
    ){

        if(
            [
                "Engineering",
                "Management",
                "University",
                "Teaching"
            ].includes(
                exam.category
            )
        ){

            score += 3;

        }

    }


    if(
        profile.type ===
        "Working Professional"
    ){

        if(
            [
                "UPSC",
                "SSC",
                "Banking",
                "Management",
                "Engineering",
                "Teaching"
            ].includes(
                exam.category
            )
        ){

            score += 3;

        }

    }


    if(
        profileText
            .includes(
                exam.category.toLowerCase()
            )
    ){

        score += 3;

    }


    /* Subjects */

    subjects.forEach(
        subject => {

            const value =
                String(
                    subject
                ).toLowerCase();


            if(
                examText.includes(value)
            ){

                score += 5;

            }


            exam.tags.forEach(
                tag => {

                    if(
                        value.includes(
                            tag.toLowerCase()
                        )
                    ){

                        score += 2;

                    }

                }
            );

        }
    );


    /* Tracked exams */

    getTrackedExams()
        .forEach(
            tracked => {

                const trackedName =
                    String(
                        tracked.name ||
                        ""
                    ).toLowerCase();


                const trackedCategory =
                    String(
                        tracked.category ||
                        ""
                    ).toLowerCase();


                if(
                    examText.includes(
                        trackedName
                    ) ||
                    trackedCategory ===
                        exam.category.toLowerCase()
                ){

                    score += 5;

                }

            }
        );


    return score;

}


/* =========================================================
   DIRECTORY FILTER
   ========================================================= */

function filteredDirectory(){

    const query =
        searchText
            .trim()
            .toLowerCase();


    return EXAM_DIRECTORY.filter(
        exam => {

            const categoryMatch =
                selectedCategory === "All" ||
                exam.category === selectedCategory;


            const searchMatch =
                !query ||
                exam.name
                    .toLowerCase()
                    .includes(query) ||
                exam.category
                    .toLowerCase()
                    .includes(query) ||
                exam.organization
                    .toLowerCase()
                    .includes(query) ||
                exam.tags.some(
                    tag =>
                        tag
                            .toLowerCase()
                            .includes(query)
                );


            return (
                categoryMatch &&
                searchMatch
            );

        }
    );

}


/* =========================================================
   RECOMMENDED EXAMS
   ========================================================= */

function renderRecommendedExams(){

    const container =
        $("recommendedExams");


    if(!container)
        return;


    const ranked =
        EXAM_DIRECTORY
            .map(
                exam => ({
                    exam,
                    score:
                        examScore(
                            exam
                        )
                })
            )
            .sort(
                (a,b) =>
                    b.score -
                    a.score
            )
            .slice(
                0,
                6
            );


    const results =
        ranked.length
            ? ranked
            : EXAM_DIRECTORY.slice(
                0,
                6
            );


    if(
        $("recommendedExamCount")
    ){

        $("recommendedExamCount")
            .textContent =
            `${results.length} matches`;

    }


    container.innerHTML =
        results
            .map(
                item => {

                    const exam =
                        item.exam;


                    const reason =
                        item.score > 0

                            ? "Matched to your profile, subjects or study interests."

                            : "Suggested starting exam.";

                    return `

                        <div
                            class="recommended-card"
                        >

                            <span
                                class="recommended-badge"
                            >
                                ⭐ RECOMMENDED
                            </span>


                            <div
                                class="directory-top"
                            >

                                <span
                                    class="directory-category"
                                >
                                    ${esc(
                                        exam.category
                                    )}
                                </span>


                                <span
                                    class="directory-org"
                                >
                                    ${esc(
                                        exam.organization
                                    )}
                                </span>

                            </div>


                            <h3>
                                ${esc(
                                    exam.name
                                )}
                            </h3>


                            <p
                                class="recommended-reason"
                            >
                                ${esc(
                                    reason
                                )}
                            </p>


                            <div
                                class="recommended-actions"
                            >

                                <a
                                    href="${esc(
                                        exam.official
                                    )}"
                                    target="_blank"
                                    rel="noopener noreferrer"
                                    class="official"
                                >
                                    Official ↗
                                </a>


                                ${
                                    exam.pyq
                                        ? `
                                            <a
                                                href="${esc(
                                                    exam.pyq
                                                )}"
                                                target="_blank"
                                                rel="noopener noreferrer"
                                                class="pyq"
                                            >
                                                ${esc(
                                                    exam.pyqLabel ||
                                                    "Papers"
                                                )} ↗
                                            </a>
                                          `
                                        : `
                                            <span
                                                class="pyq directory-pyq unavailable"
                                            >
                                                PYQs unavailable
                                            </span>
                                          `
                                }

                            </div>

                        </div>

                    `;

                }
            )
            .join("");

}


/* =========================================================
   EXAM DIRECTORY
   ========================================================= */

function renderDirectory(){

    const container =
        $("examDirectory");


    if(!container)
        return;


    const exams =
        filteredDirectory();


    if(
        $("examDirectoryCount")
    ){

        $("examDirectoryCount")
            .textContent =
            `${exams.length} exams`;

    }


    container.innerHTML =
        exams.length

            ? exams
                .map(
                    exam => `

                        <div
                            class="directory-card"
                        >

                            <div
                                class="directory-top"
                            >

                                <span
                                    class="directory-category"
                                >
                                    ${esc(
                                        exam.category
                                    )}
                                </span>


                                <span
                                    class="directory-org"
                                >
                                    ${esc(
                                        exam.organization
                                    )}
                                </span>

                            </div>


                            <h3>
                                ${esc(
                                    exam.name
                                )}
                            </h3>


                            <p>
                                ${esc(
                                    exam.info
                                )}
                            </p>


                            <div
                                class="directory-links"
                            >

                                <a
                                    href="${esc(
                                        exam.official
                                    )}"
                                    target="_blank"
                                    rel="noopener noreferrer"
                                    class="directory-link"
                                >
                                    Official Portal ↗
                                </a>


                                ${
                                    exam.pyq
                                        ? `
                                            <a
                                                href="${esc(
                                                    exam.pyq
                                                )}"
                                                target="_blank"
                                                rel="noopener noreferrer"
                                                class="directory-pyq"
                                            >
                                                ${esc(
                                                    exam.pyqLabel ||
                                                    "Papers"
                                                )} ↗
                                            </a>
                                          `
                                        : `
                                            <span
                                                class="directory-pyq unavailable"
                                            >
                                                PYQs unavailable
                                            </span>
                                          `
                                }

                            </div>

                        </div>

                    `
                )
                .join("")

            : `
                <div class="item">
                    No exams match your search.
                </div>
              `;

}


/* =========================================================
   TRACKED EXAMS
   ========================================================= */

function renderTrackedExams(
    category = "all"
){

    let exams =
        getTrackedExams();


    if(
        category !== "all"
    ){

        exams =
            exams.filter(
                exam =>
                    String(
                        exam.category ||
                        ""
                    )
                    .toLowerCase()
                    ===
                    String(
                        category
                    )
                    .toLowerCase()
            );

    }


    const container =
        $("examCards");


    if(!container)
        return;


    container.innerHTML =
        exams.length

            ? exams
                .map(
                    exam => {

                        const days =
                            daysUntil(
                                exam.date
                            );


                        return `

                            <div
                                class="exam-card"
                            >

                                <small>
                                    ${esc(
                                        exam.category ||
                                        "Custom"
                                    )}
                                </small>


                                <h3>
                                    ${esc(
                                        exam.name
                                    )}
                                </h3>


                                ${
                                    days !== null
                                        ? `
                                            <div
                                                class="exam-days"
                                            >
                                                ${
                                                    Math.max(
                                                        0,
                                                        days
                                                    )
                                                }
                                            </div>

                                            <small>
                                                DAYS LEFT
                                            </small>
                                          `
                                        : `
                                            <div
                                                class="exam-days"
                                            >
                                                —
                                            </div>

                                            <small>
                                                DATE NOT SET
                                            </small>
                                          `
                                }


                                ${
                                    exam.date
                                        ? `
                                            <p>
                                                ${dateText(
                                                    exam.date
                                                )}
                                            </p>
                                          `
                                        : ""
                                }


                                <div
                                    class="exam-links"
                                >

                                    ${
                                        exam.official
                                            ? `
                                                <a
                                                    href="${esc(
                                                        exam.official
                                                    )}"
                                                    target="_blank"
                                                    rel="noopener noreferrer"
                                                >
                                                    Official ↗
                                                </a>
                                              `
                                            : ""
                                    }


                                    ${
                                        exam.pyq
                                            ? `
                                                <a
                                                    href="${esc(
                                                        exam.pyq
                                                    )}"
                                                    target="_blank"
                                                    rel="noopener noreferrer"
                                                >
                                                    PYQs ↗
                                                </a>
                                              `
                                            : ""
                                    }

                                </div>

                            </div>

                        `;

                    }
                )
                .join("")

            : `
                <div class="item">
                    No tracked exams in this category.
                </div>
              `;

}


/* =========================================================
   CATEGORIES
   ========================================================= */

function setupDirectoryCategories(){

    const box =
        $("directoryCategories");


    if(!box)
        return;


    const categories = [
        "All",
        ...new Set(
            EXAM_DIRECTORY.map(
                exam =>
                    exam.category
            )
        )
    ];


    box.innerHTML =
        categories
            .map(
                category => `

                    <button
                        class="
                            directory-category-btn
                            ${
                                category === "All"
                                    ? "active"
                                    : ""
                            }
                        "
                        data-directory-category="${esc(
                            category
                        )}"
                        type="button"
                    >
                        ${esc(
                            category
                        )}
                    </button>

                `
            )
            .join("");


    box
        .querySelectorAll(
            "[data-directory-category]"
        )
        .forEach(
            button => {

                button.onclick =
                    () => {

                        box
                            .querySelectorAll(
                                "[data-directory-category]"
                            )
                            .forEach(
                                item =>
                                    item.classList
                                        .remove(
                                            "active"
                                        )
                            );


                        button.classList.add(
                            "active"
                        );


                        selectedCategory =
                            button.dataset
                                .directoryCategory;


                        renderDirectory();

                    };

            }
        );

}


/* =========================================================
   CUSTOM PORTALS
   ========================================================= */

function renderPortals(){

    const box =
        document.querySelector(
            ".official-box"
        );


    if(!box)
        return;


    get(
        "portals",
        []
    )
    .forEach(
        portal => {

            if(
                box.querySelector(
                    `[data-portal="${portal.id}"]`
                )
            ){

                return;

            }


            const link =
                document.createElement(
                    "a"
                );


            link.dataset.portal =
                portal.id;


            link.href =
                portal.link;


            link.target =
                "_blank";


            link.rel =
                "noopener noreferrer";


            link.textContent =
                portal.name +
                " ↗";


            const button =
                $("addPortal");


            if(button){

                button.before(
                    link
                );

            }

        }
    );

}


/* =========================================================
   INIT
   ========================================================= */

export function initExams(
    refresh = () => {}
){

    $("addExam")
        ?.addEventListener(
            "click",
            () => {

                $("examModal")
                    ?.classList
                    .remove(
                        "hidden"
                    );

            }
        );


    $("examDirectorySearch")
        ?.addEventListener(
            "input",
            event => {

                searchText =
                    event.target.value;

                renderDirectory();

            }
        );


    setupDirectoryCategories();


    document
        .querySelectorAll(
            ".exam-filter"
        )
        .forEach(
            button => {

                button.addEventListener(
                    "click",
                    () => {

                        document
                            .querySelectorAll(
                                ".exam-filter"
                            )
                            .forEach(
                                item =>
                                    item.classList
                                        .remove(
                                            "active"
                                        )
                            );


                        button.classList.add(
                            "active"
                        );


                        renderTrackedExams(
                            button.dataset.cat
                        );

                    }
                );

            }
        );


    $("examForm")
        ?.addEventListener(
            "submit",
            event => {

                event.preventDefault();


                const exams =
                    get(
                        "exams",
                        []
                    );


                exams.push({

                    id:
                        uid(),

                    name:
                        $("examName")
                            .value
                            .trim(),

                    category:
                        $("examCategory")
                            .value
                            .trim(),

                    date:
                        $("examDate")
                            .value,

                    target:
                        Number(
                            $("examTarget")
                                .value
                        ) || 0,

                    official:
                        $("examOfficial")
                            .value
                            .trim(),

                    pyq:
                        $("examPYQ")
                            .value
                            .trim()

                });


                set(
                    "exams",
                    exams
                );


                event.target.reset();


                $("examModal")
                    ?.classList
                    .add(
                        "hidden"
                    );


                renderTrackedExams();

                renderRecommendedExams();

                refresh();

            }
        );


    $("addPortal")
        ?.addEventListener(
            "click",
            () => {

                $("portalModal")
                    ?.classList
                    .remove(
                        "hidden"
                    );

            }
        );


    $("portalForm")
        ?.addEventListener(
            "submit",
            event => {

                event.preventDefault();


                const portals =
                    get(
                        "portals",
                        []
                    );


                portals.push({

                    id:
                        uid(),

                    name:
                        $("portalName")
                            .value
                            .trim(),

                    link:
                        $("portalLink")
                            .value
                            .trim()

                });


                set(
                    "portals",
                    portals
                );


                event.target.reset();


                $("portalModal")
                    ?.classList
                    .add(
                        "hidden"
                    );


                renderPortals();

            }
        );


    window.addEventListener(
        "synaptiqProfileUpdated",
        () => {

            renderRecommendedExams();

        }
    );


    renderPortals();

    renderRecommendedExams();

    renderDirectory();

    renderTrackedExams();

}


/* =========================================================
   REFRESH
   ========================================================= */

export function renderExams(){

    renderRecommendedExams();

    renderDirectory();

    renderTrackedExams();

}


/* =========================================================
   EXPORT
   ========================================================= */

export function getExamDirectory(){

    return [
        ...EXAM_DIRECTORY
    ];

}
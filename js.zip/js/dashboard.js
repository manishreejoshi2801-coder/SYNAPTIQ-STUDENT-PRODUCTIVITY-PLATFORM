import {
    get,
    set,
    $
} from "./storage.js";


/* =========================================================
   DASHBOARD STATE
   ========================================================= */

let lastDashboardUpdate = 0;


/* =========================================================
   SAFE NUMBER
   ========================================================= */

function num(value, fallback = 0){

    const n = Number(value);

    return Number.isFinite(n)
        ? n
        : fallback;
}


/* =========================================================
   SAFE ARRAY
   ========================================================= */

function arr(key){

    const value = get(key, []);

    return Array.isArray(value)
        ? value
        : [];
}


/* =========================================================
   TODAY KEY
   ========================================================= */

function todayKey(date = new Date()){

    return [
        date.getFullYear(),
        String(
            date.getMonth() + 1
        ).padStart(2, "0"),
        String(
            date.getDate()
        ).padStart(2, "0")
    ].join("-");
}


/* =========================================================
   DATE FROM VALUE
   ========================================================= */

function dateValue(value){

    if(!value)
        return null;

    const date = new Date(value);

    return Number.isNaN(
        date.getTime()
    )
        ? null
        : date;
}


/* =========================================================
   FIND SESSION DATE
   ========================================================= */

function sessionDate(session){

    return (
        session.date ||
        session.day ||
        session.createdAt ||
        session.completedAt ||
        session.startedAt ||
        null
    );
}


/* =========================================================
   FIND SESSION MINUTES
   ========================================================= */

function sessionMinutes(session){

    return num(
        session.minutes ??
        session.durationMinutes ??
        session.duration ??
        session.studyMinutes ??
        session.time ??
        0
    );
}


/* =========================================================
   STUDY SESSIONS
   ========================================================= */

function getStudySessions(){

    const possibleKeys = [
        "studySessions",
        "sessions",
        "focusSessions",
        "studyLog"
    ];

    for(const key of possibleKeys){

        const data = arr(key);

        if(data.length)
            return data;

    }

    return [];
}


/* =========================================================
   TOTAL STUDY MINUTES
   ========================================================= */

function totalStudyMinutes(){

    const sessions =
        getStudySessions();


    return sessions.reduce(
        (total, session) =>
            total +
            sessionMinutes(session),
        0
    );
}


/* =========================================================
   TODAY STUDY MINUTES
   ========================================================= */

function todayStudyMinutes(){

    const today =
        todayKey();


    return getStudySessions()
        .reduce(
            (total, session) => {

                const date =
                    dateValue(
                        sessionDate(session)
                    );


                if(
                    !date ||
                    todayKey(date) !== today
                ){
                    return total;
                }


                return (
                    total +
                    sessionMinutes(session)
                );

            },
            0
        );
}


/* =========================================================
   WEEKLY STUDY DATA
   ========================================================= */

function getWeeklyStudy(){

    const sessions =
        getStudySessions();


    const result = [
        {
            label:"M",
            minutes:0
        },
        {
            label:"T",
            minutes:0
        },
        {
            label:"W",
            minutes:0
        },
        {
            label:"T",
            minutes:0
        },
        {
            label:"F",
            minutes:0
        },
        {
            label:"S",
            minutes:0
        },
        {
            label:"S",
            minutes:0
        }
    ];


    /*
        Use Monday as the first day.
    */

    const today =
        new Date();


    const currentDay =
        today.getDay();


    const mondayOffset =
        currentDay === 0
            ? -6
            : 1 - currentDay;


    const monday =
        new Date(today);


    monday.setHours(
        0,
        0,
        0,
        0
    );


    monday.setDate(
        today.getDate() +
        mondayOffset
    );


    sessions.forEach(
        session => {

            const date =
                dateValue(
                    sessionDate(session)
                );


            if(!date)
                return;


            date.setHours(
                0,
                0,
                0,
                0
            );


            const diff =
                Math.round(
                    (
                        date -
                        monday
                    ) /
                    86400000
                );


            if(
                diff < 0 ||
                diff > 6
            ){
                return;
            }


            result[diff].minutes +=
                sessionMinutes(session);

        }
    );


    return result;
}


/* =========================================================
   FORMAT MINUTES
   ========================================================= */

function formatMinutes(minutes){

    minutes =
        Math.max(
            0,
            Math.round(
                num(minutes)
            )
        );


    if(minutes < 60){

        return `${minutes} min`;

    }


    const hours =
        Math.floor(
            minutes / 60
        );


    const mins =
        minutes % 60;


    return mins
        ? `${hours}h ${mins}m`
        : `${hours}h`;
}


/* =========================================================
   FIND TASK DATA
   ========================================================= */

function getTasks(){

    return arr("tasks");
}


/* =========================================================
   TASK PROGRESS
   ========================================================= */

function taskStats(){

    const tasks =
        getTasks();


    if(!tasks.length){

        return {
            total:0,
            completed:0,
            percent:0
        };

    }


    const completed =
        tasks.filter(
            task =>
                task.done === true ||
                task.completed === true ||
                task.status === "done"
        ).length;


    return {

        total:
            tasks.length,

        completed,

        percent:
            Math.round(
                (
                    completed /
                    tasks.length
                ) * 100
            )

    };
}


/* =========================================================
   QUESTION COUNT
   ========================================================= */

function questionCount(){

    return arr(
        "questions"
    ).length;
}


/* =========================================================
   SUBJECT DATA
   ========================================================= */

function getSubjects(){

    return arr(
        "subjects"
    );
}


/* =========================================================
   XP
   ========================================================= */

function getXP(){

    const possible =
        get(
            "xp",
            null
        );


    if(
        typeof possible ===
        "number"
    ){

        return possible;

    }


    const stats =
        get(
            "stats",
            {}
        );


    if(
        stats &&
        typeof stats.xp ===
        "number"
    ){

        return stats.xp;

    }


    const profile =
        get(
            "profile",
            {}
        );


    if(
        profile &&
        typeof profile.xp ===
        "number"
    ){

        return profile.xp;

    }


    return 0;
}


/* =========================================================
   STREAK
   ========================================================= */

function getStreak(){

    const direct =
        get(
            "streak",
            null
        );


    if(
        typeof direct ===
        "number"
    ){

        return direct;

    }


    const stats =
        get(
            "stats",
            {}
        );


    return num(
        stats?.streak,
        0
    );
}


/* =========================================================
   DAILY GOAL
   ========================================================= */

function getDailyGoal(){

    const direct =
        get(
            "dailyGoal",
            null
        );


    if(
        typeof direct ===
        "number"
    ){

        return direct;

    }


    const goal =
        get(
            "goal",
            null
        );


    if(
        typeof goal ===
        "number"
    ){

        return goal;

    }


    if(
        goal &&
        typeof goal.minutes ===
        "number"
    ){

        return goal.minutes;

    }


    const stats =
        get(
            "stats",
            {}
        );


    return num(
        stats?.dailyGoal,
        120
    ) || 120;
}


/* =========================================================
   TEST STATS
   ========================================================= */

function getTestStats(){

    const tests =
        arr("tests");


    if(!tests.length){

        return {
            total:0,
            accuracy:0
        };

    }


    let correct = 0;
    let attempts = 0;


    tests.forEach(
        test => {

            if(
                Array.isArray(
                    test.answers
                )
            ){

                test.answers.forEach(
                    answer => {

                        attempts++;


                        if(
                            answer.correct === true ||
                            answer.isCorrect === true
                        ){

                            correct++;

                        }

                    }
                );

            }


            if(
                typeof test.correct ===
                "number"
            ){

                correct +=
                    test.correct;

            }


            if(
                typeof test.total ===
                "number"
            ){

                attempts +=
                    test.total;

            }

        }
    );


    return {

        total:
            tests.length,

        accuracy:
            attempts
                ? Math.round(
                    (
                        correct /
                        attempts
                    ) * 100
                )
                : 0

    };
}


/* =========================================================
   READINESS
   ========================================================= */

function calculateReadiness(){

    const questions =
        questionCount();


    const subjects =
        getSubjects().length;


    const tasks =
        taskStats();


    const tests =
        getTestStats();


    let score = 0;


    if(subjects > 0)
        score += 25;


    if(questions > 0)
        score += 25;


    if(tasks.total > 0)
        score +=
            Math.round(
                tasks.percent * .20
            );


    if(tests.total > 0)
        score +=
            Math.round(
                tests.accuracy * .30
            );


    return Math.min(
        100,
        Math.max(
            0,
            score
        )
    );
}


/* =========================================================
   PRODUCTIVITY
   ========================================================= */

function calculateProductivity(){

    const goal =
        getDailyGoal();


    const today =
        todayStudyMinutes();


    const tasks =
        taskStats();


    const studyScore =
        goal
            ? Math.min(
                70,
                Math.round(
                    (
                        today /
                        goal
                    ) * 70
                )
            )
            : 0;


    const taskScore =
        Math.round(
            tasks.percent * .30
        );


    return Math.min(
        100,
        studyScore +
        taskScore
    );
}


/* =========================================================
   SET TEXT SAFELY
   ========================================================= */

function text(
    selector,
    value
){

    const element =
        $(selector);


    if(element){

        element.textContent =
            value;

    }
}


/* =========================================================
   SET WIDTH
   ========================================================= */

function width(
    selector,
    percent
){

    const element =
        $(selector);


    if(element){

        element.style.width =
            `${Math.max(
                0,
                Math.min(
                    100,
                    percent
                )
            )}%`;

    }
}


/* =========================================================
   LEVEL
   ========================================================= */

function renderLevel(){

    const xp =
        getXP();


    const level =
        Math.floor(
            xp / 100
        ) + 1;


    const currentXP =
        xp % 100;


    text(
        "levelName",
        `Level ${level} • ${
            level <= 1
                ? "Beginner"
                : level <= 3
                    ? "Focused Learner"
                    : level <= 5
                        ? "Consistent Learner"
                        : "Study Master"
        }`
    );


    text(
        "levelXP",
        `${currentXP} / 100 XP`
    );


    width(
        "xpBar",
        currentXP
    );


    text(
        "dashXP",
        xp
    );


    text(
        "rewardXP",
        xp
    );
}


/* =========================================================
   GOAL
   ========================================================= */

function renderGoal(){

    const goal =
        getDailyGoal();


    const today =
        todayStudyMinutes();


    const percent =
        goal
            ? Math.min(
                100,
                Math.round(
                    (
                        today /
                        goal
                    ) * 100
                )
            )
            : 0;


    text(
        "goalText",
        `${Math.round(today)} / ${Math.round(goal)} minutes`
    );


    text(
        "goalPercent",
        `${percent}%`
    );


    const circle =
        $("goalCircle");


    if(circle){

        circle.style.background =
            `conic-gradient(
                var(--primary) ${percent}%,
                #dce7f4 ${percent}%
            )`;

    }

}


/* =========================================================
   STREAK
   ========================================================= */

function renderStreak(){

    const streak =
        getStreak();


    text(
        "streak",
        streak
    );


    text(
        "rewardStreak",
        streak
    );
}


/* =========================================================
   BASIC STATS
   ========================================================= */

function renderBasicStats(){

    const study =
        totalStudyMinutes();


    const today =
        todayStudyMinutes();


    const questions =
        questionCount();


    const readiness =
        calculateReadiness();


    const productivity =
        calculateProductivity();


    text(
        "dashStudy",
        formatMinutes(study)
    );


    text(
        "dashQuestions",
        questions
    );


    text(
        "dashReady",
        `${readiness}%`
    );


    text(
        "productivity",
        productivity
    );


    text(
        "analyticsReadiness",
        `${readiness}%`
    );


    text(
        "analyticsQuestions",
        questions
    );


    /*
       Today is intentionally calculated here too,
       so timer/session data can be reflected quickly.
    */

    return {
        study,
        today,
        questions,
        readiness,
        productivity
    };
}


/* =========================================================
   WEEKLY STUDY CHART
   ========================================================= */

function renderWeeklyChart(){

    const container =
        $("weeklyChart");


    if(!container)
        return;


    const data =
        getWeeklyStudy();


    const max =
        Math.max(
            30,
            ...data.map(
                item =>
                    item.minutes
            )
        );


    container.innerHTML =
        data
            .map(
                item => {

                    const percent =
                        item.minutes > 0
                            ? Math.max(
                                5,
                                Math.round(
                                    (
                                        item.minutes /
                                        max
                                    ) * 100
                                )
                            )
                            : 3;


                    return `

                        <div
                            class="bar-day"
                            title="${item.minutes} minutes"
                        >

                            <div class="bar-wrap">

                                <div
                                    class="bar"
                                    style="
                                        height:${percent}%;
                                    "
                                ></div>

                            </div>


                            <strong>
                                ${item.minutes}
                            </strong>


                            <small>
                                ${item.label}
                            </small>

                        </div>

                    `;

                }
            )
            .join("");


    /*
       Add a message only when every day is zero.
    */

    const hasStudy =
        data.some(
            item =>
                item.minutes > 0
        );


    if(!hasStudy){

        const message =
            document.createElement(
                "div"
            );


        message.className =
            "chart-empty-message";


        message.textContent =
            "Start a focus session to build your study rhythm.";


        container.appendChild(
            message
        );

    }

}


/* =========================================================
   TASK DONUT
   ========================================================= */

function renderTaskProgress(){

    const stats =
        taskStats();


    text(
        "taskPercent",
        `${stats.percent}%`
    );


    text(
        "taskText",
        `${stats.completed} / ${stats.total} completed`
    );


    text(
        "analyticsTaskPercent",
        `${stats.percent}%`
    );


    text(
        "analyticsTaskText",
        `${stats.completed} / ${stats.total}`
    );


    const donut =
        $("taskDonut");


    if(donut){

        donut.style.background =
            `conic-gradient(
                var(--cyan) ${stats.percent}%,
                #dce7f4 ${stats.percent}%
            )`;

    }


    const analyticsDonut =
        $("analyticsDonut");


    if(analyticsDonut){

        analyticsDonut.style.background =
            `conic-gradient(
                var(--cyan) ${stats.percent}%,
                #dce7f4 ${stats.percent}%
            )`;

    }

}


/* =========================================================
   CHALLENGE
   ========================================================= */

function renderChallenge(){

    const sessions =
        getStudySessions();


    const today =
        todayKey();


    const count =
        sessions.filter(
            session => {

                const date =
                    dateValue(
                        sessionDate(
                            session
                        )
                    );


                return (
                    date &&
                    todayKey(date) ===
                    today
                );

            }
        ).length;


    const completed =
        Math.min(
            2,
            count
        );


    const percent =
        Math.round(
            (
                completed /
                2
            ) * 100
        );


    text(
        "challengeText",
        `${completed} / 2 completed`
    );


    width(
        "challengeBar",
        percent
    );

}


/* =========================================================
   SUBJECT PROGRESS
   ========================================================= */

function renderSubjectProgress(){

    const container =
        $("subjectProgress");


    const analyticsContainer =
        $("analyticsSubjects");


    const subjects =
        getSubjects();


    const targets = [];


    if(container)
        targets.push(container);


    if(
        analyticsContainer &&
        analyticsContainer !== container
    ){
        targets.push(
            analyticsContainer
        );
    }


    if(!targets.length)
        return;


    if(!subjects.length){

        const emptyHTML = `

            <div class="empty-dashboard-message">

                Add your first subject to start
                tracking subject progress.

            </div>

        `;


        targets.forEach(
            target =>
                target.innerHTML =
                    emptyHTML
        );


        return;
    }


    const html =
        subjects.map(
            subject => {

                const progress =
                    Math.max(
                        0,
                        Math.min(
                            100,
                            num(
                                subject.progress,
                                num(
                                    subject.percent,
                                    0
                                )
                            )
                        )
                    );


                return `

                    <div
                        class="subject-progress-row"
                    >

                        <div
                            class="subject-progress-head"
                        >

                            <span>
                                ${
                                    subject.name ||
                                    "Subject"
                                }
                            </span>

                            <b>
                                ${progress}%
                            </b>

                        </div>


                        <div
                            class="subject-progress-track"
                        >

                            <div
                                class="subject-progress-fill"
                                style="
                                    width:${progress}%;
                                "
                            ></div>

                        </div>

                    </div>

                `;

            }
        )
        .join("");


    targets.forEach(
        target =>
            target.innerHTML =
                html
    );

}


/* =========================================================
   TEST ANALYTICS
   ========================================================= */

function renderTestStats(){

    const tests =
        getTestStats();


    text(
        "analyticsTests",
        tests.total
    );


    text(
        "analyticsAccuracy",
        `${tests.accuracy}%`
    );
}


/* =========================================================
   SIMPLE WEEKLY ANALYTICS ALIAS
   ========================================================= */

function renderAnalyticsChart(){

    const source =
        getWeeklyStudy();


    const container =
        $("analyticsChart");


    if(!container)
        return;


    const max =
        Math.max(
            30,
            ...source.map(
                item =>
                    item.minutes
            )
        );


    container.innerHTML =
        source.map(
            item => {

                const percent =
                    item.minutes > 0
                        ? Math.max(
                            5,
                            Math.round(
                                (
                                    item.minutes /
                                    max
                                ) * 100
                            )
                        )
                        : 3;


                return `

                    <div
                        class="bar-day"
                        title="${item.minutes} minutes"
                    >

                        <div class="bar-wrap">

                            <div
                                class="bar"
                                style="
                                    height:${percent}%;
                                "
                            ></div>

                        </div>

                        <strong>
                            ${item.minutes}
                        </strong>

                        <small>
                            ${item.label}
                        </small>

                    </div>

                `;

            }
        )
        .join("");

}


/* =========================================================
   RECOMMENDATION
   ========================================================= */

function renderRecommendation(){

    const subjects =
        getSubjects();


    const questions =
        questionCount();


    const tasks =
        taskStats();


    let title =
        "Build your study space.";


    let message =
        "Add subjects and questions to personalize Synaptiq.";


    if(!subjects.length){

        title =
            "Start with your subjects.";


        message =
            "Add your subjects and chapters so Synaptiq can personalize your study recommendations.";

    }
    else if(!questions){

        title =
            "Build your Question Bank.";


        message =
            "Save important questions, doubts and PYQs for revision.";

    }
    else if(
        tasks.total === 0
    ){

        title =
            "Create your first task.";


        message =
            "Turn your study plan into manageable daily actions.";

    }
    else{

        title =
            "Keep your momentum going.";


        message =
            "Use a focus session and keep improving your weekly rhythm.";

    }


    text(
        "recommendTitle",
        title
    );


    text(
        "recommendText",
        message
    );

}


/* =========================================================
   DASHBOARD REFRESH
   ========================================================= */

export function renderDashboard(){

    const now =
        Date.now();


    /*
       Prevent accidental rapid double refreshes.
    */

    if(
        now -
        lastDashboardUpdate <
        50
    ){
        return;
    }


    lastDashboardUpdate =
        now;


    renderBasicStats();

    renderLevel();

    renderGoal();

    renderStreak();

    renderWeeklyChart();

    renderTaskProgress();

    renderChallenge();

    renderSubjectProgress();

    renderTestStats();

    renderAnalyticsChart();

    renderRecommendation();

}


/* =========================================================
   INIT
   ========================================================= */

export function initDashboard(){

    renderDashboard();


    /*
       Refresh when the dashboard becomes visible.
    */

    document
        .querySelectorAll(
            '[data-page="dashboardPage"]'
        )
        .forEach(
            button => {

                button.addEventListener(
                    "click",
                    () => {

                        setTimeout(
                            renderDashboard,
                            50
                        );

                    }
                );

            }
        );


    /*
       Refresh periodically so completed
       timer sessions appear without reopening
       the page.
    */

    setInterval(
        () => {

            const page =
                $("dashboardPage");


            if(
                page &&
                !page.classList.contains(
                    "hidden"
                )
            ){

                renderDashboard();

            }

        },
        5000
    );

}


/* =========================================================
   OPTIONAL REFRESH FUNCTION
   ========================================================= */

export function updateDashboard(){

    renderDashboard();

}
import {
    get,
    set,
    uid,
    $
} from "./storage.js";


const PLANNER_KEY =
    "synaptiqPlanner";


let currentMonth =
    new Date();


let selectedDate =
    null;


/* =========================================================
   DATA
   ========================================================= */

function getSubjects(){

    const subjects =
        get(
            "subjects",
            []
        );


    return Array.isArray(
        subjects
    )
        ? subjects
        : [];

}


function getPlanner(){

    return get(
        PLANNER_KEY,
        null
    );

}


function savePlanner(
    planner
){

    set(
        PLANNER_KEY,
        planner
    );

}


/* =========================================================
   HELPERS
   ========================================================= */

function escapeHtml(
    value
){

    return String(
        value || ""
    )
    .replace(
        /&/g,
        "&amp;"
    )
    .replace(
        /</g,
        "&lt;"
    )
    .replace(
        />/g,
        "&gt;"
    )
    .replace(
        /"/g,
        "&quot;"
    )
    .replace(
        /'/g,
        "&#039;"
    );

}


function splitSubjects(
    value
){

    return String(
        value || ""
    )
    .split(",")
    .map(
        item =>
            item.trim()
    )
    .filter(Boolean);

}


function dateKey(
    date
){

    const year =
        date.getFullYear();


    const month =
        String(
            date.getMonth() + 1
        )
        .padStart(
            2,
            "0"
        );


    const day =
        String(
            date.getDate()
        )
        .padStart(
            2,
            "0"
        );


    return `${year}-${month}-${day}`;

}


function daysUntil(
    date
){

    const target =
        new Date(
            `${date}T23:59:59`
        );


    const today =
        new Date();


    today.setHours(
        0,
        0,
        0,
        0
    );


    return Math.max(
        1,
        Math.ceil(
            (
                target -
                today
            ) /
            86400000
        )
    );

}


/* =========================================================
   BUILD PAGE
   ========================================================= */

function buildPlannerPage(){

    const page =
        $("plannerPage");


    if(!page)
        return;


    page.innerHTML = `

        <div class="page-head">

            <div>

                <small>
                    ADAPTIVE PLANNER
                </small>

                <h1>
                    Study Planner
                </h1>

                <p>
                    Plan your preparation day by day.
                </p>

            </div>

        </div>


        <div class="planner-workspace">

            <div class="panel">

                <small>
                    PLAN SETUP
                </small>

                <h2>
                    Generate Your Study Plan
                </h2>

                <p>
                    Synaptiq will distribute your study sessions
                    according to your exam date, study time,
                    strong subjects and weak subjects.
                </p>


                <form
                    id="fullPlannerForm"
                    class="planner-form"
                >

                    <div class="planner-form-grid">

                        <div>

                            <label>
                                Exam / Goal
                            </label>

                            <input
                                id="plannerExam"
                                placeholder="GATE, JEE, UPSC, Semester Exam..."
                                required
                            >

                        </div>


                        <div>

                            <label>
                                Exam Date
                            </label>

                            <input
                                id="plannerDate"
                                type="date"
                                required
                            >

                        </div>


                        <div>

                            <label>
                                Daily Study Hours
                            </label>

                            <input
                                id="plannerHours"
                                type="number"
                                min="0.5"
                                max="16"
                                step="0.5"
                                value="3"
                                required
                            >

                        </div>


                        <div>

                            <label>
                                Study Days / Week
                            </label>

                            <input
                                id="plannerDays"
                                type="number"
                                min="1"
                                max="7"
                                value="6"
                                required
                            >

                        </div>


                        <div>

                            <label>
                                Target Score
                            </label>

                            <input
                                id="plannerTarget"
                                type="number"
                                min="0"
                                max="100"
                                value="75"
                            >

                        </div>


                        <div>

                            <label>
                                Preferred Study Time
                            </label>

                            <select
                                id="plannerPreferredTime"
                            >

                                <option>
                                    Flexible
                                </option>

                                <option>
                                    Morning
                                </option>

                                <option>
                                    Afternoon
                                </option>

                                <option>
                                    Evening
                                </option>

                                <option>
                                    Night
                                </option>

                            </select>

                        </div>

                    </div>


                    <label>
                        Strong Subjects
                    </label>

                    <input
                        id="plannerStrong"
                        placeholder="Example: DBMS, CN, Mathematics"
                    >


                    <label>
                        Weak Subjects
                    </label>

                    <input
                        id="plannerWeak"
                        placeholder="Example: OS, COA"
                    >


                    <label>
                        Subjects To Prioritize
                    </label>

                    <input
                        id="plannerPriority"
                        placeholder="Example: OS, DSA"
                    >


                    <label>
                        Additional Instructions
                    </label>

                    <textarea
                        id="plannerNotes"
                        placeholder="Example: Keep Sunday lighter and give weak subjects extra revision."
                    ></textarea>


                    <button
                        class="primary"
                        type="submit"
                    >
                        ✨ Generate Adaptive Plan
                    </button>

                </form>

            </div>


            <div class="panel">

                <small>
                    PLAN COMMAND
                </small>

                <h2>
                    Modify Your Plan
                </h2>

                <p>
                    You can modify an existing plan.
                </p>


                <textarea
                    id="plannerCommand"
                    placeholder="Example: Give OS two extra sessions and keep Sunday free."
                ></textarea>


                <button
                    id="modifyPlanner"
                    class="outline"
                    type="button"
                >
                    Apply Modification
                </button>


                <div
                    id="plannerCommandMessage"
                    class="test-message"
                ></div>

            </div>

        </div>


        <div
            id="plannerSummary"
            class="planner-summary"
        ></div>


        <div
            class="calendar-panel panel"
        >

            <div class="calendar-head">

                <div>

                    <small>
                        STUDY CALENDAR
                    </small>

                    <h2 id="calendarTitle">
                        ${currentMonth.toLocaleString(
                            "en-US",
                            {
                                month:"long",
                                year:"numeric"
                            }
                        )}
                    </h2>

                </div>


                <div class="calendar-controls">

                    <button
                        id="previousMonth"
                        class="outline"
                        type="button"
                    >
                        ←
                    </button>


                    <button
                        id="todayMonth"
                        class="small-btn"
                        type="button"
                    >
                        Today
                    </button>


                    <button
                        id="nextMonth"
                        class="outline"
                        type="button"
                    >
                        →
                    </button>

                </div>

            </div>


            <div
                id="plannerCalendar"
                class="planner-calendar"
            ></div>


            <div
                id="selectedDayPanel"
                class="selected-day-panel"
            ></div>

        </div>


        <div
            id="plannerCards"
            class="planner-grid"
        ></div>

    `;

}


/* =========================================================
   GENERATE SCHEDULE
   ========================================================= */

function generateSchedule(
    plan
){

    const start =
        new Date();


    start.setHours(
        0,
        0,
        0,
        0
    );


    const end =
        new Date(
            `${plan.examDate}T23:59:59`
        );


    const totalDays =
        Math.max(
            1,
            Math.ceil(
                (
                    end -
                    start
                ) /
                86400000
            )
        );


    const subjects =
        [
            ...new Set(
                [
                    ...plan.priority,
                    ...plan.weak,
                    ...plan.strong,
                    ...getSubjects()
                        .map(
                            subject =>
                                subject.name
                        )
                        .filter(Boolean)
                ]
            )
        ];


    if(!subjects.length){

        subjects.push(
            "General Preparation"
        );

    }


    const orderedSubjects =
        [
            ...plan.priority,
            ...plan.weak,
            ...subjects
        ];


    const uniqueSubjects =
        [
            ...new Set(
                orderedSubjects
            )
        ];


    const schedule = {};


    for(
        let day = 0;
        day < totalDays;
        day++
    ){

        const current =
            new Date(
                start
            );


        current.setDate(
            current.getDate() +
            day
        );


        /*
           Do not schedule beyond exam date.
        */

        if(
            current >
            end
        ){

            break;

        }


        /*
           Keep the requested number
           of study days per week.
        */

        const weekday =
            current.getDay();


        const weeklyLimit =
            plan.studyDays;


        if(
            weeklyLimit < 7 &&
            weekday >= weeklyLimit
        ){

            continue;

        }


        /*
           Every few days reserve
           lighter revision.
        */

        let sessions = [];


        const primary =
            uniqueSubjects[
                day %
                uniqueSubjects.length
            ];


        sessions.push({
            subject:primary,
            type:
                plan.weak.some(
                    item =>
                        item.toLowerCase()
                        ===
                        primary.toLowerCase()
                )
                    ? "Weak Topic"
                    : "Concept Study",
            duration:
                Math.max(
                    30,
                    Math.round(
                        plan.hours *
                        60 /
                        2
                    )
                )
        });


        const secondary =
            uniqueSubjects[
                (
                    day + 1
                ) %
                uniqueSubjects.length
            ];


        sessions.push({
            subject:
                secondary,
            type:
                day % 5 === 4
                    ? "Revision"
                    : "Practice",
            duration:
                Math.max(
                    30,
                    Math.round(
                        plan.hours *
                        60 /
                        3
                    )
                )
        });


        if(
            day % 7 === 5
        ){

            sessions.push({

                subject:
                    "Mock / PYQ",

                type:
                    "Exam Practice",

                duration:
                    Math.max(
                        30,
                        Math.round(
                            plan.hours *
                            60 /
                            2
                        )
                    )

            });

        }


        schedule[
            dateKey(
                current
            )
        ] =
            sessions;

    }


    return schedule;

}


/* =========================================================
   GENERATE PLAN
   ========================================================= */

function generatePlanner(
    event
){

    event.preventDefault();


    const exam =
        $("plannerExam")
            ?.value
            .trim();


    const examDate =
        $("plannerDate")
            ?.value;


    const hours =
        Number(
            $("plannerHours")
                ?.value
        );


    const studyDays =
        Number(
            $("plannerDays")
                ?.value
        );


    if(
        !exam ||
        !examDate ||
        !hours ||
        !studyDays
    ){

        return;

    }


    const plan = {

        id:
            uid(),

        exam,

        examDate,

        hours,

        studyDays,

        target:
            Number(
                $("plannerTarget")
                    ?.value
            ) || 75,

        preferredTime:
            $("plannerPreferredTime")
                ?.value ||
                "Flexible",

        strong:
            splitSubjects(
                $("plannerStrong")
                    ?.value
            ),

        weak:
            splitSubjects(
                $("plannerWeak")
                    ?.value
            ),

        priority:
            splitSubjects(
                $("plannerPriority")
                    ?.value
            ),

        notes:
            $("plannerNotes")
                ?.value
                .trim(),

        createdAt:
            new Date()
                .toISOString()

    };


    plan.remainingDays =
        daysUntil(
            examDate
        );


    plan.totalHours =
        Math.round(
            plan.remainingDays *
            hours *
            (
                studyDays /
                7
            ) *
            10
        ) / 10;


    plan.schedule =
        generateSchedule(
            plan
        );


    savePlanner(
        plan
    );


    currentMonth =
        new Date();


    selectedDate =
        null;


    renderAll(
        plan
    );

}


/* =========================================================
   SUMMARY
   ========================================================= */

function renderSummary(
    plan
){

    const summary =
        $("plannerSummary");


    if(!summary)
        return;


    summary.innerHTML = `

        <div
            class="planner-summary-card"
        >

            <div>

                <small>
                    YOUR ACTIVE PLAN
                </small>

                <h2>
                    ${escapeHtml(
                        plan.exam
                    )}
                </h2>

                <p>
                    Exam:
                    ${escapeHtml(
                        plan.examDate
                    )}
                    •
                    ${plan.remainingDays}
                    days remaining
                    •
                    ${plan.hours}
                    hrs/day
                    •
                    ${plan.studyDays}
                    days/week
                </p>

            </div>


            <div
                class="planner-metrics"
            >

                <div>

                    <strong>
                        ${plan.totalHours}
                    </strong>

                    <span>
                        Total Hours
                    </span>

                </div>


                <div>

                    <strong>
                        ${plan.target}%
                    </strong>

                    <span>
                        Target
                    </span>

                </div>


                <div>

                    <strong>
                        ${Object.keys(
                            plan.schedule ||
                            {}
                        ).length}
                    </strong>

                    <span>
                        Study Days
                    </span>

                </div>

            </div>

        </div>

    `;

}


/* =========================================================
   CALENDAR
   ========================================================= */

function renderCalendar(
    plan
){

    const calendar =
        $("plannerCalendar");


    if(!calendar)
        return;


    const year =
        currentMonth.getFullYear();


    const month =
        currentMonth.getMonth();


    const firstDay =
        new Date(
            year,
            month,
            1
        );


    const lastDay =
        new Date(
            year,
            month + 1,
            0
        );


    const startWeekday =
        firstDay.getDay();


    const totalDays =
        lastDay.getDate();


    const weekdays = [
        "Sun",
        "Mon",
        "Tue",
        "Wed",
        "Thu",
        "Fri",
        "Sat"
    ];


    let html = "";


    weekdays.forEach(
        day => {

            html += `

                <div
                    class="calendar-weekday"
                >
                    ${day}
                </div>

            `;

        }
    );


    for(
        let i = 0;
        i < startWeekday;
        i++
    ){

        html += `

            <div
                class="calendar-cell empty"
            ></div>

        `;

    }


    const today =
        dateKey(
            new Date()
        );


    for(
        let day = 1;
        day <= totalDays;
        day++
    ){

        const date =
            new Date(
                year,
                month,
                day
            );


        const key =
            dateKey(
                date
            );


        const sessions =
            plan?.schedule?.[key] ||
            [];


        const isToday =
            key === today;


        const isSelected =
            key ===
            selectedDate;


        const beforeStart =
            date <
            new Date(
                new Date()
                    .setHours(
                        0,
                        0,
                        0,
                        0
                    )
            );


        const isExam =
            key ===
            plan?.examDate;


        html += `

            <button
                type="button"
                class="
                    calendar-cell
                    ${isToday ? "today" : ""}
                    ${isSelected ? "selected" : ""}
                    ${sessions.length ? "has-study" : ""}
                    ${isExam ? "exam-day" : ""}
                    ${beforeStart ? "past-day" : ""}
                "
                data-date="${key}"
            >

                <span
                    class="calendar-number"
                >
                    ${day}
                </span>


                ${
                    sessions.length

                        ? `

                            <span
                                class="calendar-dot"
                            ></span>

                            <span
                                class="calendar-session-count"
                            >
                                ${sessions.length}
                                ${sessions.length === 1
                                    ? "session"
                                    : "sessions"}
                            </span>

                          `

                        : ""

                }


                ${
                    isExam
                        ? `
                            <span
                                class="calendar-exam-label"
                            >
                                EXAM
                            </span>
                          `
                        : ""
                }

            </button>

        `;

    }


    calendar.innerHTML =
        html;


    calendar
        .querySelectorAll(
            "[data-date]"
        )
        .forEach(
            button => {

                button.addEventListener(
                    "click",
                    () => {

                        selectedDate =
                            button.dataset.date;


                        renderCalendar(
                            plan
                        );


                        renderSelectedDay(
                            plan
                        );

                    }
                );

            }
        );


    const title =
        $("calendarTitle");


    if(title){

        title.textContent =
            currentMonth.toLocaleString(
                "en-US",
                {
                    month:"long",
                    year:"numeric"
                }
            );

    }

}


/* =========================================================
   SELECTED DAY
   ========================================================= */

function renderSelectedDay(
    plan
){

    const panel =
        $("selectedDayPanel");


    if(!panel)
        return;


    if(!selectedDate){

        panel.innerHTML = `

            <div class="selected-empty">

                <span>
                    📅
                </span>

                <p>
                    Select a day on the calendar
                    to view its study sessions.
                </p>

            </div>

        `;

        return;

    }


    const sessions =
        plan?.schedule?.[
            selectedDate
        ] ||
        [];


    const date =
        new Date(
            `${selectedDate}T12:00:00`
        );


    const formatted =
        date.toLocaleDateString(
            "en-US",
            {
                weekday:"long",
                month:"long",
                day:"numeric",
                year:"numeric"
            }
        );


    panel.innerHTML = `

        <div class="selected-day-head">

            <div>

                <small>
                    SELECTED DAY
                </small>

                <h3>
                    ${formatted}
                </h3>

            </div>


            <span>
                ${sessions.length}
                ${
                    sessions.length === 1
                        ? "session"
                        : "sessions"
                }
            </span>

        </div>


        <div class="day-session-list">

            ${
                sessions.length

                    ? sessions
                        .map(
                            (
                                session,
                                index
                            ) => `

                                <div
                                    class="day-session"
                                >

                                    <div
                                        class="session-number"
                                    >
                                        ${index + 1}
                                    </div>


                                    <div>

                                        <strong>
                                            ${escapeHtml(
                                                session.subject
                                            )}
                                        </strong>

                                        <p>
                                            ${escapeHtml(
                                                session.type
                                            )}
                                            •
                                            ${session.duration}
                                            min
                                        </p>

                                    </div>

                                </div>

                            `
                        )
                        .join("")

                    : `

                        <div
                            class="selected-empty"
                        >

                            <span>
                                🌙
                            </span>

                            <p>
                                No study session planned
                                for this day.
                            </p>

                        </div>

                      `
            }

        </div>

    `;

}


/* =========================================================
   WEEKLY SESSION CARDS
   ========================================================= */

function renderCards(
    plan
){

    const cards =
        $("plannerCards");


    if(!cards)
        return;


    const entries =
        Object.entries(
            plan.schedule ||
            {}
        )
        .slice(
            0,
            12
        );


    cards.innerHTML =
        entries
            .map(
                (
                    [
                        date,
                        sessions
                    ]
                ) => {

                    const dateObj =
                        new Date(
                            `${date}T12:00:00`
                        );


                    const label =
                        dateObj.toLocaleDateString(
                            "en-US",
                            {
                                weekday:"short",
                                month:"short",
                                day:"numeric"
                            }
                        );


                    return `

                        <div
                            class="planner-card"
                        >

                            <span>
                                ${label}
                            </span>


                            <h3>
                                ${sessions.length}
                                Study Sessions
                            </h3>


                            ${
                                sessions
                                    .map(
                                        session => `

                                            <p>
                                                <strong>
                                                    ${escapeHtml(
                                                        session.subject
                                                    )}
                                                </strong>

                                                <br>

                                                ${escapeHtml(
                                                    session.type
                                                )}
                                                •
                                                ${session.duration}
                                                min
                                            </p>

                                        `
                                    )
                                    .join("")
                            }

                        </div>

                    `;

                }
            )
            .join("");

}


/* =========================================================
   MONTH NAVIGATION
   ========================================================= */

function setupCalendarControls(){

    $("previousMonth")
        ?.addEventListener(
            "click",
            () => {

                currentMonth =
                    new Date(
                        currentMonth.getFullYear(),
                        currentMonth.getMonth() - 1,
                        1
                    );


                renderCalendar(
                    getPlanner()
                );

            }
        );


    $("nextMonth")
        ?.addEventListener(
            "click",
            () => {

                currentMonth =
                    new Date(
                        currentMonth.getFullYear(),
                        currentMonth.getMonth() + 1,
                        1
                    );


                renderCalendar(
                    getPlanner()
                );

            }
        );


    $("todayMonth")
        ?.addEventListener(
            "click",
            () => {

                currentMonth =
                    new Date();


                selectedDate =
                    dateKey(
                        new Date()
                    );


                const planner =
                    getPlanner();


                renderCalendar(
                    planner
                );


                renderSelectedDay(
                    planner
                );

            }
        );

}


/* =========================================================
   MODIFY PLAN
   ========================================================= */

function modifyPlanner(){

    const command =
        $("plannerCommand")
            ?.value
            .trim();


    const plan =
        getPlanner();


    if(!plan){

        $("plannerCommandMessage")
            .textContent =
            "Generate a plan first.";

        return;

    }


    if(!command){

        return;

    }


    const lower =
        command.toLowerCase();


    if(
        lower.includes("sunday") &&
        (
            lower.includes("free") ||
            lower.includes("off")
        )
    ){

        Object.keys(
            plan.schedule
        )
        .forEach(
            key => {

                const date =
                    new Date(
                        `${key}T12:00:00`
                    );


                if(
                    date.getDay() ===
                    0
                ){

                    delete plan.schedule[
                        key
                    ];

                }

            }
        );

    }


    if(
        lower.includes("more time") ||
        lower.includes("extra")
    ){

        plan.hours =
            Math.min(
                16,
                plan.hours + .5
            );

    }


    if(
        lower.includes("less time")
    ){

        plan.hours =
            Math.max(
                .5,
                plan.hours - .5
            );

    }


    plan.lastModification =
        command;


    savePlanner(
        plan
    );


    renderAll(
        plan
    );


    $("plannerCommandMessage")
        .textContent =
        "Plan updated successfully.";

}


/* =========================================================
   RENDER EVERYTHING
   ========================================================= */

function renderAll(
    plan
){

    renderSummary(
        plan
    );

    renderCalendar(
        plan
    );

    renderSelectedDay(
        plan
    );

    renderCards(
        plan
    );

}


/* =========================================================
   INIT
   ========================================================= */

export function initPlanner(){

    buildPlannerPage();


    $("fullPlannerForm")
        ?.addEventListener(
            "submit",
            generatePlanner
        );


    $("modifyPlanner")
        ?.addEventListener(
            "click",
            modifyPlanner
        );


    setupCalendarControls();


    const saved =
        getPlanner();


    if(saved){

        renderAll(
            saved
        );

    }
    else{

        renderCalendar(
            null
        );

        renderSelectedDay(
            null
        );

    }

}


/* =========================================================
   REFRESH
   ========================================================= */

export function renderPlanner(){

    const planner =
        getPlanner();


    if(planner){

        renderAll(
            planner
        );

    }

}
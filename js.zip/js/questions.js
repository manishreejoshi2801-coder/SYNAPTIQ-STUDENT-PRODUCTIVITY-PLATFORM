import {
    get,
    set,
    uid,
    $,
    esc
} from "./storage.js";

let filter = "all";
let view = "all";

let revision = [];
let ri = 0;
let flash = null;

function fill() {

    const s =
        get("subjects", []);

    $("questionSubject").innerHTML =
        s.length
            ? s.map(
                x =>
                    `<option>
                        ${esc(x.name)}
                     </option>`
              ).join("")
            : "<option>General</option>";
}

export function renderQuestions() {

    let q =
        get("questions", []);

    const search =
        $("questionSearch")
            .value
            .trim()
            .toLowerCase();

    q =
        q.filter(
            x =>
                (
                    x.text
                        .toLowerCase()
                        .includes(search) ||
                    x.subject
                        .toLowerCase()
                        .includes(search)
                ) &&
                (
                    filter === "all" ||
                    x.tag === filter
                ) &&
                (
                    view === "all" ||
                    (
                        view === "pyq" &&
                        x.tag === "PYQ"
                    ) ||
                    (
                        view === "mistake" &&
                        x.tag === "MISTAKE"
                    )
                )
        );

    $("questionCards").innerHTML =
        q.length
            ? q.map(
                x => `
                    <div class="question-card">

                        <div class="question-head">

                            <div class="question-text">

                                ${
                                    x.important
                                        ? "⭐ "
                                        : ""
                                }

                                ${esc(x.text)}

                            </div>

                            <span class="tag">
                                ${esc(x.tag)}
                            </span>

                        </div>

                        <div class="meta">
                            ${esc(x.subject)}
                            ${
                                x.topic
                                    ? " • " +
                                      esc(x.topic)
                                    : ""
                            }
                        </div>

                        <div class="question-actions">

                            <button
                                data-qdone="${x.id}">
                                ${
                                    x.done
                                        ? "✅ Done"
                                        : "○ Mark Done"
                                }
                            </button>

                            <button
                                data-qmistake="${x.id}">
                                ❌ Mistake
                            </button>

                            <button
                                data-qflash="${x.id}">
                                🧠 Flashcard
                            </button>

                            <button
                                data-qdelete="${x.id}">
                                🗑 Delete
                            </button>

                        </div>

                    </div>
                `
              ).join("")
            : "<div class='item'>No questions found.</div>";
}

function showRevision() {

    const q =
        revision[ri];

    $("revisionTitle")
        .textContent =
        q.subject;

    $("revisionCount")
        .textContent =
        `Question ${ri + 1} / ${revision.length}`;

    $("revisionQuestion")
        .textContent =
        q.text;

    $("revisionModal")
        .classList
        .remove("hidden");
}

export function initQuestions(refresh) {

    $("addQuestion").onclick = () => {

        fill();

        $("questionModal")
            .classList
            .remove("hidden");
    };

    $("questionSearch").oninput =
        renderQuestions;

    document
        .querySelectorAll(".filter")
        .forEach(
            b =>
                b.onclick = () => {

                    document
                        .querySelectorAll(".filter")
                        .forEach(
                            x =>
                                x.classList
                                 .remove("active")
                        );

                    b.classList.add("active");

                    filter =
                        b.dataset.filter;

                    renderQuestions();
                }
        );

    $("showAllQuestions").onclick = () => {

        view = "all";

        document
            .querySelectorAll(".tab")
            .forEach(
                x =>
                    x.classList
                     .remove("active")
            );

        $("showAllQuestions")
            .classList
            .add("active");

        renderQuestions();
    };

    $("showPYQQuestions").onclick = () => {

        view = "pyq";

        document
            .querySelectorAll(".tab")
            .forEach(
                x =>
                    x.classList
                     .remove("active")
            );

        $("showPYQQuestions")
            .classList
            .add("active");

        renderQuestions();
    };

    $("showMistakes").onclick = () => {

        view = "mistake";

        document
            .querySelectorAll(".tab")
            .forEach(
                x =>
                    x.classList
                     .remove("active")
            );

        $("showMistakes")
            .classList
            .add("active");

        renderQuestions();
    };

    $("questionForm").onsubmit =
        e => {

            e.preventDefault();

            const q =
                get("questions");

            q.push({
                id: uid(),
                text:
                    $("questionText")
                        .value
                        .trim(),
                subject:
                    $("questionSubject")
                        .value,
                topic:
                    $("questionTopic")
                        .value
                        .trim(),
                tag:
                    $("questionTag")
                        .value,
                difficulty:
                    $("questionDifficulty")
                        .value,
                done: false,
                important:
                    $("questionTag")
                        .value ===
                    "IMPORTANT"
            });

            set("questions", q);

            e.target.reset();

            $("questionModal")
                .classList
                .add("hidden");

            renderQuestions();

            refresh();
        };

    document.addEventListener(
        "click",
        e => {

            let id =
                e.target.dataset.qdone;

            if (id) {

                const q =
                    get("questions");

                const x =
                    q.find(
                        a => a.id === id
                    );

                if (x)
                    x.done = !x.done;

                set("questions", q);

                renderQuestions();

                refresh();
            }


            id =
                e.target.dataset.qmistake;

            if (id) {

                const q =
                    get("questions");

                const x =
                    q.find(
                        a => a.id === id
                    );

                if (x)
                    x.tag = "MISTAKE";

                set("questions", q);

                renderQuestions();
            }


            id =
                e.target.dataset.qdelete;

            if (id) {

                set(
                    "questions",
                    get("questions")
                        .filter(
                            x => x.id !== id
                        )
                );

                renderQuestions();

                refresh();
            }


            id =
                e.target.dataset.qflash;

            if (id) {

                flash =
                    get("questions")
                        .find(
                            x => x.id === id
                        );

                if (flash) {

                    $("flashContent")
                        .textContent =
                        flash.text;

                    $("flashModal")
                        .classList
                        .remove("hidden");
                }
            }
        }
    );

    $("quickRevision").onclick = () => {

        revision =
            get("questions")
                .filter(
                    x => !x.done
                );

        if (!revision.length)
            return alert(
                "No pending questions."
            );

        ri = 0;

        showRevision();
    };

    $("examRevision").onclick = () => {

        revision =
            get("questions")
                .filter(
                    x =>
                        x.tag === "PYQ" ||
                        x.tag === "IMPORTANT"
                );

        if (!revision.length)
            return alert(
                "No exam questions saved."
            );

        ri = 0;

        showRevision();
    };

    $("revisionPrev").onclick = () => {

        if (ri > 0) {
            ri--;
            showRevision();
        }
    };

    $("revisionNext").onclick = () => {

        if (
            ri <
            revision.length - 1
        ) {
            ri++;
            showRevision();
        }
    };

    $("revisionAgain").onclick =
        () => {};

    $("revisionKnow").onclick = () => {

        const q =
            get("questions");

        const x =
            q.find(
                a =>
                    a.id ===
                    revision[ri].id
            );

        if (x)
            x.done = true;

        set("questions", q);

        revision.splice(ri, 1);

        if (!revision.length) {

            $("revisionModal")
                .classList
                .add("hidden");

            return;
        }

        ri =
            Math.min(
                ri,
                revision.length - 1
            );

        showRevision();
    };

    $("flashFlip").onclick = () => {

        if (flash) {

            $("flashContent")
                .textContent =
                `Subject: ${flash.subject}
Topic: ${flash.topic || "General"}
Difficulty: ${flash.difficulty}`;
        }
    };
}
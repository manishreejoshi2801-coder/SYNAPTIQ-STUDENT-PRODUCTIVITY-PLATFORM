import {
    get,
    set,
    uid,
    $,
    esc
} from "./storage.js";

let selected = "";

export function renderSubjects() {

    const s =
        get("subjects", []);

    $("subjectCards").innerHTML =
        s.length
            ? s.map(x => {

                const n =
                    x.chapters.length;

                const d =
                    x.chapters.filter(
                        c => c.done
                    ).length;

                const p =
                    n
                        ? Math.round(d / n * 100)
                        : 0;

                return `
                    <div class="subject-card">

                        <div class="subject-top">
                            <b>${p}%</b>
                        </div>

                        <h3>
                            ${esc(x.name)}
                        </h3>

                        <p>
                            ${d}/${n} chapters
                        </p>

                        <div class="progress-line">
                            <div
                                style="
                                    width:${p}%
                                ">
                            </div>
                        </div>

                        ${
                            x.chapters.map(
                                c => `
                                    <label class="chapter">

                                        <input
                                            type="checkbox"
                                            data-subject="${x.id}"
                                            data-chapter="${c.id}"
                                            ${c.done ? "checked" : ""}
                                        >

                                        <span>
                                            ${esc(c.name)}
                                        </span>

                                    </label>
                                `
                            ).join("")
                        }

                        <button
                            class="add-chapter"
                            data-add-chapter="${x.id}">
                            + Add Chapter
                        </button>

                    </div>
                `;

            }).join("")
            : "<div class='item'>No subjects yet.</div>";
}

export function initSubjects(refresh) {

    $("addSubject").onclick =
        () =>
            $("subjectModal")
                .classList
                .remove("hidden");

    $("subjectForm").onsubmit =
        e => {

            e.preventDefault();

            const s =
                get("subjects");

            s.push({
                id: uid(),
                name:
                    $("subjectName")
                        .value
                        .trim(),
                color:
                    $("subjectColor")
                        .value,
                notes:
                    $("subjectNotes")
                        .value
                        .trim(),
                chapters: []
            });

            set("subjects", s);

            e.target.reset();

            $("subjectModal")
                .classList
                .add("hidden");

            renderSubjects();

            refresh();
        };

    $("chapterForm").onsubmit =
        e => {

            e.preventDefault();

            const s =
                get("subjects");

            const x =
                s.find(
                    a =>
                        a.id === selected
                );

            if (x) {
                x.chapters.push({
                    id: uid(),
                    name:
                        $("chapterName")
                            .value
                            .trim(),
                    notes:
                        $("chapterNotes")
                            .value
                            .trim(),
                    done: false
                });
            }

            set("subjects", s);

            e.target.reset();

            $("chapterModal")
                .classList
                .add("hidden");

            renderSubjects();

            refresh();
        };

    document.addEventListener(
        "click",
        e => {

            const b =
                e.target.closest(
                    "[data-add-chapter]"
                );

            if (b) {

                selected =
                    b.dataset.addChapter;

                $("chapterModal")
                    .classList
                    .remove("hidden");
            }
        }
    );

    document.addEventListener(
        "change",
        e => {

            if (!e.target.dataset.subject)
                return;

            const s =
                get("subjects");

            const x =
                s.find(
                    a =>
                        a.id ===
                        e.target.dataset.subject
                );

            const c =
                x?.chapters.find(
                    a =>
                        a.id ===
                        e.target.dataset.chapter
                );

            if (c) {

                c.done =
                    e.target.checked;

                set("subjects", s);

                renderSubjects();

                refresh();
            }
        }
    );
}